# The Journal

Open `index.html` in any modern browser. No build step.

- `css/style.css` styles
- `js/app.js` journal, memories, playlists, newsletter validation

Data (entries, photos, playlist links, daily checklist) is stored in your browser's localStorage. Fonts load from Google Fonts (internet needed for them; fallbacks are included).
The newsletter form validates input only; connect a mailing service to make it send.
