const $=s=>document.querySelector(s),E=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ld=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch(e){return d}};
const sv=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}};
const RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
// hero words
"Some moments deserve to be remembered.".split(' ').forEach((w,i)=>{$('#h1').insertAdjacentHTML('beforeend',`<span class="w" aria-hidden="true"><span style="animation-delay:${.8+i*.18}s">${w}&nbsp;</span></span>`)});
// nav
const nav=$('#nav');addEventListener('scroll',()=>{nav.classList.toggle('s',scrollY>60);if(!RM&&scrollY<innerHeight)$('#px').style.transform=`translateY(${scrollY*.12}px)`},{passive:true});
$('#burger').onclick=e=>{const o=$('#menu').classList.toggle('o');e.target.setAttribute('aria-expanded',o)};
$('#menu').onclick=e=>{if(e.target.tagName=='A')$('#menu').classList.remove('o')};
// reveal
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.12});
document.querySelectorAll('.rv').forEach(e=>io.observe(e));
// cursor
const cu=$('#cur');addEventListener('pointermove',e=>{cu.style.left=e.clientX+'px';cu.style.top=e.clientY+'px';cu.classList.toggle('h',!!e.target.closest('a,button,.pol,.a,input,.chip'))});
// modal
const md=$('#md');let lastF;
function open(h){lastF=document.activeElement;$('#box').innerHTML='<button class="x" aria-label="Close">×</button>'+h;md.classList.add('o');$('#box .x').focus();$('#box .x').onclick=close}
function close(){md.classList.remove('o');lastF&&lastF.focus()}
md.onclick=e=>{if(e.target==md)close()};addEventListener('keydown',e=>{if(e.key=='Escape')close()});
document.addEventListener('keydown',e=>{if((e.key=='Enter'||e.key==' ')&&e.target.matches&&e.target.matches('[role=button]')){e.preventDefault();e.target.click()}});
// todo
const items=['Take a walk','Listen to something beautiful','Write something','Appreciate the little things'];
const today=new Date().toDateString();let td=ld('todo',{});if(td.d!=today)td={d:today,c:[]};
$('#todo').innerHTML=items.map((t,i)=>`<label><input type="checkbox" data-i="${i}" ${td.c.includes(i)?'checked':''}><span>${t}</span></label>`).join('');
$('#todo').onchange=e=>{const i=+e.target.dataset.i;td.c=td.c.filter(x=>x!=i);if(e.target.checked)td.c.push(i);sv('todo',td)};
// prompts
const P=['What small thing made you smile today?','Describe a place you want to return to.','What would you tell yourself a year ago?','Write about a sound you love.','What are you carrying that you could set down?','Describe your perfect slow morning.','Who made you feel at home recently?'];
let pi=new Date().getDate()%P.length;const sp=()=>$('#pr').textContent='“'+P[pi]+'”';sp();$('#np').onclick=()=>{pi=(pi+1)%P.length;sp()};
// journal
const M=['Happy','Peaceful','Nostalgic','Melancholic','Anxious','Inspired','Grateful'];let mood='',eid=null,ents=ld('ents',[]);if(!Array.isArray(ents))ents=[];
$('#mood').innerHTML=M.map(m=>`<button class="chip" data-m="${m}" aria-pressed="false">${m}</button>`).join('');
$('#fm').insertAdjacentHTML('beforeend',M.map(m=>`<option>${m}</option>`).join(''));
$('#mood').onclick=e=>{const b=e.target.closest('[data-m]');if(!b)return;mood=mood==b.dataset.m?'':b.dataset.m;document.querySelectorAll('#mood .chip').forEach(c=>{const on=c.dataset.m==mood;c.classList.toggle('on',on);c.setAttribute('aria-pressed',on)})};
document.querySelector('.tb').onmousedown=e=>{if(e.target.closest('button'))e.preventDefault()};document.querySelector('.tb').onclick=e=>{const b=e.target.closest('[data-c]');if(b){e.preventDefault();$('#body').focus();document.execCommand(b.dataset.c)}};
$('#usep').onclick=()=>{$('#body').focus();document.execCommand('insertText',false,P[pi]+' ')};
const clean=h=>{const t=document.createElement('template');t.innerHTML=h;t.content.querySelectorAll('script,style,iframe,object,embed,link').forEach(n=>n.remove());t.content.querySelectorAll('*').forEach(n=>[...n.attributes].forEach(a=>{if(/^on|^style$|^href$|^src$/i.test(a.name))n.removeAttribute(a.name)}));return t.innerHTML};
const txt=h=>{const t=document.createElement('template');t.innerHTML=h;return t.content.textContent.replace(/\s+/g,' ').trim()};const fmt=t=>new Date(t).toLocaleString([],{dateStyle:'medium',timeStyle:'short'});
function reset(){eid=null;$('#title').value='';$('#body').innerHTML='';$('#tags').value='';mood='';document.querySelectorAll('#mood .chip').forEach(c=>{c.classList.remove('on');c.setAttribute('aria-pressed',false)});$('#smsg').textContent=''}
$('#clear').onclick=reset;$('#body').oninput=e=>{if(!e.target.textContent.trim()&&!e.target.querySelector('img,li'))e.target.innerHTML=''};
$('#save').onclick=()=>{const html=clean($('#body').innerHTML),txt=$('#body').textContent.trim(),title=$('#title').value.trim()||'Untitled page';
if(!txt){$('#smsg').textContent='Write something before saving.';return}
const tags=$('#tags').value.split(',').map(t=>t.trim()).filter(Boolean),now=Date.now();
if(eid){const e=ents.find(x=>x.id==eid);Object.assign(e,{title,html,mood,tags,upd:now})}else ents.unshift({id:now,title,html,mood,tags,created:now,upd:now});
const ok=sv('ents',ents);if(ok)reset();$('#smsg').textContent=ok?'Saved '+fmt(now)+'.':'Could not save: browser storage is full or blocked.';render()};
function render(){const q=$('#q').value.toLowerCase(),fm=$('#fm').value,fd=$('#fd').value;
const r=ents.filter(e=>(!q||(e.title+' '+txt(e.html)+' '+e.tags.join(' ')).toLowerCase().includes(q))&&(!fm||e.mood==fm)&&(!fd||new Date(e.created).toLocaleDateString('en-CA')==fd));
$('#list').innerHTML=r.length?r.map(e=>`<article class="entry"><h3>${E(e.title)}</h3><p class="meta">${fmt(e.created)}${e.mood?' · '+e.mood:''}${e.tags.length?' · #'+e.tags.map(E).join(' #'):''}</p><p style="margin:6px 0">${E(txt(e.html).slice(0,140))}${txt(e.html).length>140?'…':''}</p><button class="chip" data-e="${e.id}">Edit</button> <button class="chip" data-d="${e.id}">Delete</button></article>`).join(''):`<p class="hand" style="font-size:26px">${ents.length?'No pages match those filters.':'Your first page is waiting. Write it on the left.'}</p>`}
['#q','#fm','#fd'].forEach(s=>$(s).oninput=render);
$('#list').onclick=e=>{const b=e.target.closest('button');if(!b)return;
if(b.dataset.e){const x=ents.find(i=>i.id==b.dataset.e);eid=x.id;$('#title').value=x.title;$('#body').innerHTML=clean(x.html);$('#tags').value=x.tags.join(', ');mood=x.mood;document.querySelectorAll('#mood .chip').forEach(c=>{const on=c.dataset.m==mood;c.classList.toggle('on',on);c.setAttribute('aria-pressed',on)});$('#smsg').textContent='Editing “'+x.title+'”';$('#nb').scrollIntoView({behavior:'smooth',block:'center'})}
if(b.dataset.d){const id=b.dataset.d;open(`<h3>Delete this entry?</h3><p style="margin:10px 0 18px">This can’t be undone.</p><button class="btn" id="yes" style="background:var(--char);color:var(--ivory)">Delete entry</button> <button class="btn" id="no" style="border-color:var(--char)">Keep it</button>`);$('#yes').onclick=()=>{ents=ents.filter(x=>x.id!=id);sv('ents',ents);if(eid==id)reset();render();close()};$('#no').onclick=close}};
render();
// typing placeholder
if(!RM){const t='Dear diary, today I...';let i=0,d=1;setInterval(()=>{const b=$('#body');if(b.textContent||document.activeElement==b)return;i+=d;if(i>t.length+12)d=-1;if(i<=0)d=1;b.dataset.ph=t.slice(0,Math.max(0,Math.min(i,t.length)))||'|'},130)}
// memories
let mems=ld('mems',[]),col='';if(!Array.isArray(mems))mems=[];
function rm(){const cs=[...new Set(mems.map(m=>m.col).filter(Boolean))];
$('#cols').innerHTML=cs.length?['',...cs].map(c=>`<button class="chip ${c==col?'on':''}" data-c="${E(c)}">${c?E(c):'All'}</button>`).join(''):'';
const v=mems.filter(m=>!col||m.col==col);
$('#mem').innerHTML=v.length?v.map(m=>`<div class="pol" role="button" tabindex="0" data-id="${m.id}"><div class="ph" style="background-image:url(${m.img})"></div><div class="cap">${E(m.cap)}</div></div>`).join(''):'<p class="hand" style="font-size:28px">No photos yet. Add your first memory above.</p>'}
$('#cols').onclick=e=>{const b=e.target.closest('[data-c]');if(b){col=b.dataset.c;rm()}};
$('#mf').onsubmit=e=>{e.preventDefault();const f=$('#mfile').files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const s=Math.min(1,900/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=im.width*s;c.height=im.height*s;c.getContext('2d').drawImage(im,0,0,c.width,c.height);
mems.unshift({id:Date.now(),img:c.toDataURL('image/jpeg',.7),cap:$('#mcap').value,date:$('#mdate').value,loc:$('#mloc').value,col:$('#mcol').value.trim()});
if(!sv('mems',mems)){mems.shift();alert('Storage is full. Delete a memory and try again.')}else $('#mf').reset();rm()};im.onerror=()=>alert('That file could not be read as an image.');im.src=r.result};r.readAsDataURL(f)};
$('#mem').onclick=e=>{const b=e.target.closest('[data-id]');if(!b)return;const m=mems.find(x=>x.id==b.dataset.id);
open(`<img src="${m.img}" alt="${E(m.cap)}"><h3 style="margin-top:12px">${E(m.cap)}</h3><p class="meta">${[m.date,m.loc,m.col].filter(Boolean).map(E).join(' · ')}</p><button class="chip" id="dm" style="margin-top:10px">Delete memory</button>`);
$('#dm').onclick=()=>{mems=mems.filter(x=>x.id!=m.id);sv('mems',mems);rm();close()}};rm();
// articles
const A=[['Slow Mornings in the City','Coffee steam, soft light, and the quiet before the streets wake up.','May 12, 2026','4 min','linear-gradient(160deg,#d9a49b,#a47d5b)','Some mornings ask nothing of you. Open the window, let the kettle take its time, and watch the city stretch. Write down what you hear before the day starts talking back.'],
['Things I Never Said','Unsent letters and the relief of finally writing them down.','May 8, 2026','6 min','linear-gradient(160deg,#233D32,#a5aa91)','Some sentences live in your chest for years. Put them on paper without a recipient. You do not have to send them; you only have to stop carrying them alone.'],
['A Letter to My Younger Self','Gentle advice for someone who was trying so hard.','Apr 30, 2026','5 min','linear-gradient(160deg,#e9ddc9,#d9a49b)','You were allowed to rest. The friendships that mattered were the ones that stayed easy. Most of what you feared never arrived, and the rest you survived.'],
['Why I Still Keep a Journal','Paper remembers what we hide from ourselves.','Apr 22, 2026','3 min','linear-gradient(160deg,#142B25,#a47d5b)','A journal is not a record of big events. It is proof that you noticed your life while it was happening, one small page at a time.'],
['The Beauty of Ordinary Days','Nothing happened today. That was the gift.','Apr 14, 2026','4 min','linear-gradient(160deg,#a5aa91,#f5ebdd)','Ordinary days make up most of a life. Learn to love laundry on the line, the second cup of tea, the walk home with no destination.'],
['Learning to Be Alone','Solitude, without the loneliness.','Apr 2, 2026','7 min','linear-gradient(160deg,#252522,#233D32)','Alone is a place you can furnish. Start small: a chair by the window, a book, a plan with no one but yourself.'],
['Somewhere Between Yesterday and Tomorrow','On nostalgia, hope, and the present tense.','Mar 25, 2026','5 min','linear-gradient(160deg,#d9a49b,#233D32)','The past is warm because we have edited it. The future is bright because we have not lived it. Today is the draft in between, and it counts.']];
$('#art').innerHTML=A.map((a,i)=>`<div class="a rv" role="button" tabindex="0" data-a="${i}"><div class="im"><i style="background:${a[4]}"></i></div><h3>${a[0]}</h3><p>${a[1]}</p><p class="meta">${a[2]} · ${a[3]} read</p><span class="hand" style="font-size:22px;color:var(--rose)">Read more</span></div>`).join('');
document.querySelectorAll('.a').forEach(e=>io.observe(e));
$('#art').onclick=e=>{const b=e.target.closest('[data-a]');if(!b)return;const a=A[b.dataset.a];open(`<div style="height:120px;background:${a[4]};margin:-34px -34px 18px"></div><h2 style="font-size:40px">${a[0]}</h2><p class="meta">${a[2]} · ${a[3]} read</p><p style="margin-top:12px">${a[5]}</p>`)};
// playlists
const PL=[['Midnight Thoughts','#142B25,#233D32','#F5EBDD'],['Slow Sunday','#e9ddc9,#d9a49b','#252522'],['Nostalgic Memories','#a47d5b,#252522','#F5EBDD'],['Rainy Window','#a5aa91,#233D32','#F5EBDD'],['Quiet Happiness','#d9a49b,#f5ebdd','#252522']];
let pl=ld('pl',{});
function rp(){$('#pls').innerHTML=PL.map((p,i)=>{const d=pl[i]||{s:[]};return`<div class="pc"><div class="al" style="background:linear-gradient(150deg,${p[1]});color:${p[2]}">${p[0]}</div><h3 style="font-size:26px">${p[0]}</h3>
${d.l?`<a class="btn" style="padding:6px 16px;margin:6px 0;display:inline-block" href="${E(d.l)}" target="_blank" rel="noopener">Open in Spotify</a>`:''}
<ul>${d.s.map(s=>`<li>${E(s)}</li>`).join('')}</ul>
<input data-l="${i}" placeholder="Paste Spotify playlist link" aria-label="Spotify link for ${p[0]}" value="${E(d.l||'')}"><input data-s="${i}" placeholder="Add song: Title, Artist (Enter)" aria-label="Add song to ${p[0]}"></div>`}).join('')}
$('#pls').onchange=e=>{const t=e.target,i=t.dataset.l??t.dataset.s;pl[i]=pl[i]||{s:[]};
if(t.dataset.l!==undefined){const v=t.value.trim();if(!v||/^https:\/\/open\.spotify\.com\//.test(v))pl[i].l=v;else alert('Please paste a link starting with https://open.spotify.com/')}
else if(t.value.trim())pl[i].s.push(t.value.trim());sv('pl',pl);rp()};rp();
// newsletter
$('#nf').onsubmit=e=>{e.preventDefault();const v=$('#em').value.trim(),m=$('#nm');
if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v)){m.textContent='Enter a valid email, like name@example.com.';m.style.color='#7a2a20';return}
m.style.color='var(--forest)';m.textContent='Email looks good. Subscriptions are not connected to a mailing service yet, so nothing was sent or stored.'};
